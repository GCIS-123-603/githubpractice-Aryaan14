"""
This program demonstrates an interactive HappinessMeasurement system that calculates the Happiness Measurement of countries using Country class and a Happiness Meter class

Authors: Aryaan Roy, Ashton Pinto

Date: November 29, 2023
"""
class Country:
    """
    Represents a country and its attributes
    """

    #Attributes of the country
    __slots__ = ['__name','__environment','__economy','__culture','__healthcare','__education']

    #Initialize attributes of the country privately
    def __init__(self, name="", environment=0, economy=0, culture=0, healthcare=0, education=0):
        self.__name = name
        self.__environment = environment
        self.__economy = economy
        self.__culture = culture
        self.__healthcare = healthcare
        self.__education = education
    
    #Mutator/Setter methods for each attribute
    def set_name(self, name):
        self.__name = name
    
    def set_environment(self, environment):
        self.__environment = environment
    
    def set_economy(self, economy):
        self.__economy = economy
    
    def set_culture(self, culture):
        self.__culture = culture
    
    def set_healthcare(self, healthcare):
        self.__healthcare = healthcare
    
    def set_education(self, education):
        self.__education = education

    #Accessor/Getter methods for each attribute, used to retrieve the attribute to use for calculation in HappinessMeter Class
    def get_name(self):
        return self.__name
    
    def get_environment(self):
        return self.__environment
    
    def get_economy(self):
        return self.__economy
    
    def get_culture(self):
        return self.__culture
    
    def get_healthcare(self):
        return self.__healthcare
    
    def get_education(self):
        return self.__education

class HappinessMeter:
    """
    Measures happiness scores for countries.
    """

    #Initialize countries empty list
    def __init__(self):
        self.countries = []
    
    #Method to add a country to the list
    def add_country(self, country):
        self.countries.append(country)
    
    def measure_happiness(self):
        """
        Iterates through countries list and Measures/Calculates average happiness score of each country in list
        """
        for country in self.countries:
            happiness_score = (int(country.get_environment()) + int(country.get_economy()) + int(country.get_culture()) + int(country.get_healthcare()) + int(country.get_education())) / 5

            rounded_score = round(happiness_score,2)

            print(country.get_name(),": Happiness score is:",rounded_score)

def main():
    """
    Main function to collect data and measure happiness_meter
    """
    
    countries = int(input("Enter the number of countries: "))
    country_number = 1
    happiness_meter = HappinessMeter()

    #For loop to collect data for each country 
    for i in range(countries):
        country_name = input(str(f"Enter the name of country {country_number}: "))
        environment = int(input("Enter environment factor (1-100): "))
        economy = int(input("Enter economy factor (1-100): "))
        culture = int(input("Enter culture factor (1-100): "))
        healthcare = int(input("Enter healthcare factor (1-100): "))
        education = int(input("Enter education factor (1-100): "))
        print("\n")

        #Creating country object
        country = Country()

        #Setting the country's attributes using setters
        country.set_name(country_name)
        country.set_environment(environment)
        country.set_economy(economy)
        country.set_culture(culture)
        country.set_healthcare(healthcare)
        country.set_education(education)

        #Adding the country to Happiness Meter
        happiness_meter.add_country(country)
        country_number += 1

    print("Happiness Measurement: ")

    #Calling measure_happiness method to calculate and print the happiness score of the country
    happiness_meter.measure_happiness()

main()