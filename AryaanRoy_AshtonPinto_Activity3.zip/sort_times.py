import time
import plotter
import random
import sys 
"""
This program demonstrates plotting time analysis of different sorting methods on random and sorted arrays, as well as a mix insertion and quicksort method :)
Author: Aryaan Roy, Ashton Pinto
Date: November 16, 2023
"""

"""Sort method codes (InsertionSort,MergeSort,QuickSort,QuickInsertionSort) that are needed for program"""
def insertion_sort(arr): #Insertion sort function
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key


def merge(arr, left, mid, right): #Merge sort code
    n1 = mid - left + 1
    n2 = right - mid

    left_arr = [0] * n1
    right_arr = [0] * n2

    for i in range(n1):
        left_arr[i] = arr[left + i]

    for j in range(n2):
        right_arr[j] = arr[mid + 1 + j]

    i = j = 0
    k = left

    while i < n1 and j < n2:
        if left_arr[i] <= right_arr[j]:
            arr[k] = left_arr[i]
            i += 1
        else:
            arr[k] = right_arr[j]
            j += 1
        k += 1

    while i < n1:
        arr[k] = left_arr[i]
        i += 1
        k += 1

    while j < n2:
        arr[k] = right_arr[j]
        j += 1
        k += 1


def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2
        left_half = arr[:mid]
        right_half = arr[mid:]

        merge_sort(left_half)
        merge_sort(right_half)

        merge(arr, 0, mid - 1, len(arr) - 1)


def partition(arr, low, high): #function part of Quick sort code
    pivot = arr[high]
    i = low - 1

    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def quick_sort(arr, low=None, high=None):
    if low is None:
        low = 0
    if high is None:
        high = len(arr) - 1

    if low < high:
        pivot = partition(arr, low, high)

        quick_sort(arr, low, pivot - 1)
        quick_sort(arr, pivot + 1, high)


def quick_insertion_sort(array): 
    """mix of QuickSort and InsertionSort
      begins with Quicksort, but if the array is already sorted or nearly sorted, it switches to Insertion sort"""

    if len(array) < 2:
        return array
    #if Quick sort is not performing well and then switching to Insertion sort,
    #if array is sorted or nearly sorted, then it will switch to insertion sort.
    if array == sorted(array):
        return insertion_sort(array)

    #Quick Sort to begin the sort
    quick_sort(array, 0, len(array) - 1)

    return array


def sort_function_timer(sort_function, an_array):
    """Measuring the time taken by a sorting function to sort an array."""
    start = time.time()  
    sort_function(an_array) 
    end = time.time()  
    elapsed_time = end - start  
    return elapsed_time 

#global array SIZES
SIZES = list(range(200, 2001, 300))  #from 200 to 2000 with a step of 300

def plot_sort_time_using_random_arrays(sort_function):
    """Plotting and printing the time taken by a sorting function for random value arrays of various sizes."""

    print("timing", sort_function.__name__)
    plotter.new_series()

    for i in SIZES:
        random_array = [random.randint(0, 1000) for _ in range(i)] #creating a random array with the given size from SIZES using list comprehension

        elapsed_time = sort_function_timer(sort_function, random_array) #measuring the time taken to sort the random array with a sort method

        plotter.add_data_point(elapsed_time) #adding point to plotter


def plot_sort_time_using_sorted_arrays(sort_function):
    """Plotting and printing the time taken by a sorting function for sorted arrays of various sizes"""

    print("timing", sort_function.__name__)
    plotter.new_series()

    for i in SIZES:
        sorted_array = list(range(i)) #creating a sorted array given size from SIZES

        
        elapsed_time = sort_function_timer(sort_function, sorted_array) #measuring the time taken to sort the sorted array with a sort method

        plotter.add_data_point(elapsed_time)

def main():
    sys.setrecursionlimit(10**6) #precaution to not get recursion depth issue
    plotter.init("Sorting Time Analysis", "Size of Array", "Time (s)")
    plot_sort_time_using_random_arrays(insertion_sort)
    plot_sort_time_using_random_arrays(merge_sort)
    plot_sort_time_using_random_arrays(quick_sort)
    plot_sort_time_using_random_arrays(quick_insertion_sort)  #quick_insertion_sort with random arrays
    plot_sort_time_using_sorted_arrays(insertion_sort)
    plot_sort_time_using_sorted_arrays(merge_sort)
    plot_sort_time_using_sorted_arrays(quick_sort)
    plot_sort_time_using_sorted_arrays(quick_insertion_sort) #quick_insertion_sort with sorted arrays
    plotter.plot()
    input("")

main()
