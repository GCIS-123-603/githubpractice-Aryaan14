"""
Module: Task Scheduler Program
Team Members: Aryaan Roy, Ashton Pinto

This program demonstrates creating a schedule for tasks depending on their dependencies. 
November 23, 2023

"""
#Can use any tasks samples from activity3 pdf file in program
tasks_dependencies = {
    'T4': ['T3'],
    'T3': ['T2', 'T1'],
    'T2': ['T1'],
    'T1': []
}


def mirror(tasks_dependencies):
    """
    Mirrors the task dependencies by creating a dictionary in which each task is a key,
    and its value are the tasks depending on them.
    
    """
    dependency_tasks = {}

    for task, dependencies in tasks_dependencies.items(): #iterate through each task and its dependencies
        if task not in dependency_tasks: #add the task to dependency_tasks if not present
            dependency_tasks[task] = []

        #updating dependency_tasks, if dependency not in dependency_tasks, create a new list
        for dependency in dependencies:
            if dependency not in dependency_tasks:
                dependency_tasks[dependency] = [task]
            else:
                dependency_tasks[dependency].append(task)

    return dependency_tasks


def remove_value(list_tasks, Tx, tasks_dependencies):
    """
    Removes any given Tx from the dependency lists of tasks

    """
    for task in list_tasks: #loop through each task in the provided list of tasks  
        if task in tasks_dependencies:  #check if the task is in the task dependencies dictionary
            if Tx in tasks_dependencies[task]: #check if 'Tx' exists in the dependencies of the current task, if it is a dependency, removes it
                tasks_dependencies[task].remove(Tx)

    keys_with_empty_values = []
    for task, dependencies in tasks_dependencies.items():
        if not dependencies:
            keys_with_empty_values.append(task)

    return keys_with_empty_values

def schedule(tasks_dependencies):
    """
    Creates a scheudle/ordered list of tasks based on their dependencies.
    """
    ordered_tasks = []
    dependency_tasks = mirror(tasks_dependencies)

    for _ in range(len(tasks_dependencies)):
        independent_tasks = []

        for task, dependencies in dependency_tasks.items(): #find tasks without dependencies
            if not dependencies:
                independent_tasks.append(task)

        if not independent_tasks:
            break

        for task in independent_tasks:  #add independent tasks to the ordered list
            ordered_tasks.append(task)

        for task in independent_tasks: #remove independent tasks from dependency_tasks
            del dependency_tasks[task]

        for task in independent_tasks: #using remove_value function to remove added tasks from other tasks dependencies
            remove_value(dependency_tasks.keys(), task, dependency_tasks)

    reversed_ordered_tasks = list(reversed(ordered_tasks))

    #if no remaining tasks, it means a scheduling can't be done
    if dependency_tasks:
        return []
    else:
        return reversed_ordered_tasks



def main():
    result = schedule(tasks_dependencies)
    print(result)


main()